#include "Energia.h"

#line 1 "C:/Users/sheis/workspace_v11/Blink/Blink.ino"













#define LED RED_LED



  

void setup();
void loop();

#line 20
void setup() {                
  
  pinMode(LED, OUTPUT);     
}


void loop() {
  digitalWrite(LED, HIGH);   
  delay(500);               
  digitalWrite(LED, LOW);    
  delay(500);               
}



